if exists (select * from sys.server_event_sessions where name= 'pssdiag_xevent') drop  EVENT SESSION [pssdiag_xevent] ON SERVER 
GO
CREATE EVENT SESSION [pssdiag_xevent] ON SERVER 
ADD EVENT sqlserver.file_write_completed (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
WITH (MAX_MEMORY=200800 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=10 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=PER_CPU,TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.file_write_enqueued (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_apply_log_block (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_apply_vlfheader (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_capture_compressed_log_cache (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_capture_filestream_wait (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_capture_log_block (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_capture_vlfheader (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_database_flow_control_action (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_db_commit_mgr_harden (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_db_commit_mgr_harden_still_waiting (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_db_commit_mgr_update_harden (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_filestream_processed_block (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_log_block_compression (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_log_block_decompression (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_log_block_group_commit (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_log_block_send_complete (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_lsn_send_complete (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_receive_harden_lsn_message (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_send_harden_lsn_message (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_transport_dump_message (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_transport_flow_control_action (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hadr_transport_receive_log_block_message (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.log_block_pushed_to_logpool (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.log_flush_complete (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.log_flush_start (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.recovery_unit_harden_log_timestamps (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT ucs.ucs_connection_flow_control (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT ucs.ucs_connection_recv_io (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT ucs.ucs_connection_recv_msg (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT ucs.ucs_connection_send_io (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT ucs.ucs_connection_send_msg (     ACTION (package0.callstack, sqlos.task_address, sqlos.worker_address)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.broker_corrupted_message (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.broker_forwarded_message_dropped (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.broker_message_undeliverable (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.cursor_implicit_conversion (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.databases_log_growth (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.databases_log_shrink (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.additional_memory_grant (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.attention (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.background_job_error (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.batch_hash_table_build_bailout (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.blocked_process_report (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.cpu_threshold_exceeded (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.database_suspect_data_page (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.error_reported (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.exchange_spill (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.execution_warning (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.filestream_file_io_failure (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.hash_warning (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.missing_column_statistics ( SET collect_column_list=(1)      ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.missing_join_predicate (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.sort_warning (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.auto_stats (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.plan_guide_successful (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.plan_guide_unsuccessful (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.rpc_completed ( SET collect_data_stream=(1)      ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.rpc_starting (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.sp_cache_remove (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.sql_batch_completed ( SET collect_batch_text=(1)      ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.sql_batch_starting (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.sql_statement_recompile (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.lock_deadlock (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.lock_escalation (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.lock_timeout (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.server_memory_change (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.existing_connection ( SET collect_database_name=(1)      ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.login ( SET collect_options_text=(1)      ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
GO
alter  EVENT SESSION [pssdiag_xevent] ON SERVER  ADD EVENT sqlserver.logout (     ACTION (package0.event_sequence, sqlserver.client_app_name, sqlserver.client_hostname, sqlserver.client_pid, sqlserver.database_id, sqlserver.database_name, sqlserver.is_system, sqlserver.nt_username, sqlserver.query_hash, sqlserver.request_id, sqlserver.server_principal_name, sqlserver.session_server_principal_name, sqlserver.session_id, sqlserver.session_nt_username, sqlserver.sql_text, sqlserver.transaction_id, sqlserver.username)     )
