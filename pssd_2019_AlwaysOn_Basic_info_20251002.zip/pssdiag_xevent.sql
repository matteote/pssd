if exists (select * from sys.server_event_sessions where name= 'pssdiag_xevent') drop  EVENT SESSION [pssdiag_xevent] ON SERVER 
GO
CREATE EVENT SESSION [pssdiag_xevent] ON SERVER 
