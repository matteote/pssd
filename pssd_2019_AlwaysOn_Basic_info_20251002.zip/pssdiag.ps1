
param
(
    [Parameter(ParameterSetName = 'ServiceRelated',Mandatory=$true)]
    [Parameter(Position = 0)]
    [string] $ServiceState = "",

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $help,

    [Parameter(ParameterSetName = 'Config',HelpMessage='/I xml_config_file',Mandatory=$false)]
    [string] $I = "pssdiag.xml",

    [Parameter(ParameterSetName = 'Config',HelpMessage='/O output_path',Mandatory=$false)]
    [string] $O = "output",

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $P = "",

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $N = "1",

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $M = [string]::Empty,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $Q ,
    
    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $C = "0",

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $G,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $R,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $U,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $A = [string]::Empty,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $L,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $X,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $B = [string]::Empty,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $E = [string]::Empty,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [string] $T = [string]::Empty,

    [Parameter(ParameterSetName = 'Config',Mandatory=$false)]
    [switch] $DebugOn


)


. ./Confirm-FileAttributes.ps1


function Check-ElevatedAccess
{
    try 
    {
	
        #check for administrator rights
        if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator))
        {
            Write-Warning "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") Elevated privilege (run as Admininstrator) is required to run PSSDIAG. Exiting..."
            exit
        }
        
    }

    catch 
    {
        Write-Error "Error occured in $($MyInvocation.MyCommand), $($PSItem.Exception.Message ), line number: $($PSItem.InvocationInfo.ScriptLineNumber)" 
		exit
    }
    

}


function FindSQLDiag ()
{

    try
    {
				
        [bool]$is64bit = $false

        [xml]$xmlDocument = Get-Content -Path .\pssdiag.xml
        [string]$sqlver = $xmlDocument.dsConfig.Collection.Machines.Machine.Instances.Instance.ssver
		
		#first find out if their registry is messed up
		ValidateCurrentVersion -ssver $sqlver

		[string[]] $valid_versions = "10", "10.50", "11", "12", "13", "14", "15", "16"

		while ($sqlver -notin $valid_versions)
		{
			Write-Warning "An invalid version is specified for SQL Server (ssver = '$sqlver') in the pssdiag.xml file. This prevents selecting correct SQLDiag.exe path."
			$sqlver = Read-Host "Please enter the 2-digit version of your SQL Server ($valid_versions) to help locate SQLDiag.exe"

		}

        if ($sqlver -eq "10.50")
        {
              $sqlver = "10"
        }

        [string]$plat = $xmlDocument.dsConfig.DiagMgrInfo.IntendedPlatform


        [string] $x86Env = [Environment]::GetEnvironmentVariable( "CommonProgramFiles(x86)");


         #[System.Environment]::Is64BitOperatingSystem

        if ($x86Env -ne $null)
        {
            $is64bit = $true
        }

        $toolsRegStr = ("HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\" + $sqlver+"0\Tools\ClientSetup")
		
	
	
        # for higher versions of PS use: [string]$toolsBinFolder = Get-ItemPropertyValue -Path $toolsRegStr -Name Path
        [string]$toolsBinFolder = (Get-ItemProperty -Path $toolsRegStr -Name Path).Path


		#strip "(x86)" in case Powershell goes to HKLM\SOFTWARE\WOW6432Node\Microsoft\Microsoft SQL Server\ under the covers, which it does
		
		$toolsBinFolderx64 = $toolsBinFolder.Replace("Program Files (x86)", "Program Files")

		
		$sqldiagPath = ($toolsBinFolder + "sqldiag.exe")
        $sqldiagPathx64 = ($toolsBinFolderx64 + "sqldiag.exe")
		
		
	
        if ((Test-Path -Path $sqldiagPathx64))
        {
			return $sqldiagPathx64
		}
		
		else
		{
			#path was not valid so checking second path
			
			if ($sqldiagPath -ne $sqldiagPathx64)
			{
				if ((Test-Path -Path $sqldiagPath))
				{
					return $sqldiagPath
				}
			}
			
			Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") Unable to find 'sqldiag.exe' version: $($sqlver)0 on this machine.  Data collection will fail"
			return "Path_Error_"
        }
        
		
    }
    catch 
    {
        Write-Error "Error occured in finding SQLDiag.exe: $($PSItem.Exception.Message)  line number: $($PSItem.InvocationInfo.ScriptLineNumber)" 
		return "Path_Error_"
    }

}

function ValidateCurrentVersion ([string]$ssver)
{
	[string[]] $intermediateNames = @()
	[string[]] $currentVersionReg = @()

	$regInstNames = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL" 
	
	$instNames = Get-Item $regInstNames | Select-Object -ExpandProperty Property 

	# add the discovered values in an array
	foreach ($inst in $instNames)
	{
		# for higher versions of Powershell use: $intermediateNames+= ( Get-ItemPropertyValue -Path $regInstNames -Name $inst)
        $intermediateNames+= ( Get-ItemProperty -Path $regInstNames -Name $inst).$inst
	}


	[int] $nonMatchCounter = 0

	foreach($name in $intermediateNames)
	{

		$regRoot = "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\" + $name + "\MSSQLServer\CurrentVersion"
		
        # for higher versions of PS use: $verString = Get-ItemPropertyValue -Path $regRoot -Name CurrentVersion
        $verString = (Get-ItemProperty -Path $regRoot -Name CurrentVersion).CurrentVersion

		$currentVersionReg+= ($regRoot + "=>" + $verString)

		# get the major version value from the reg entry
		$majVersion = $verString.Substring(0, $verString.IndexOf("."))

        # for version 2008R2 number is 10.50 and we had to remove .50
        #IndexOf function returns -1 for SQLs without minor version number (only 2008R2 has this number, which is 50. All others are zero). 

        if ($ssver.IndexOf(".") -eq -1) 
        {
            $tempssver =  $ssver

        }
        else 
        {
            $tempssver = $ssver.Substring(0, $ssver.IndexOf("."))
        }



        if ($majVersion -ne $tempssver)
		{
			$nonMatchCounter++
		}

	}

    if ($nonMatchCounter -eq $intermediateNames.Count)
	{
		Write-Warning "Collection may fail. No instance was found for the version of SQL Server configured in pssdiag.xml (ssver='$ssver')."
        Write-Warning "Examine these reg keys to see if the one or more versions is different from expected version $ssver (first 2 digits in NN.n.nnnn):`n"
        foreach ($entry in $currentVersionReg)
		{
			Write-Warning $entry 
		}
	}

}



function PrintHelp
{
	 Write-Host " [-I cfgfile] = sets the configuration file, typically either pssdiag.xml or sqldiag.xml.`n"`
        "[-O outputpath] = sets the output folder.  Defaults to startupfolder\SQLDIAG (if the folder does not exist, the collector will attempt to create it) `n" `
        "[-N #] = output folder management at startup #: 1 = overwrite (default), 2 = rename (format is OUTPUT_00001,...00002, etc.) `n" `
        "[-P supportpath] = sets the support path folder.  Defaults to startupfolder if not specified `n" `
        "[-M machine1 [machine2 machineN]|`@machinelistfile] = overrides the machines specified in the config file. When specifying more than one machine, separate each machine name with a space. "`@" specifies a machine list file `n" `
        "[-Q]  = quiet mode -- supresses prompts (e.g., password prompts) `n" `
        "[-C #] = file compression type: 0 = none (default), 1 = NTFS, 2 = CAB `n" `
        "[-G]  = generic mode -- SQL Server connectivity checks are not enforced; machine enumeration includes all servers, not just SQL Servers `n" `
        "[-R]  = registers the collector as a service `n" `
        "[-U]  = unregisters the collector as a service `n" `
        "[-A appname] = sets the application name.  If running as a service, this sets the service name `n" `
        "[-L] = continuous mode -- automatically restarts when shutdown via -X or -E `n" `
        "[-X] = snapshot mode -- takes a snapshot of all configured diagnostics and shuts down immediately `n" `
        "[-B [+]YYYYMMDD_HH:MM:SS] = specifies the date/time to begin collecting data; "+HH:MM:SS" specifies a relative time `n" `
        "[-E [+]YYYYMMDD_HH:MM:SS]  = specifies the date/time to end data collection; "+HH:MM:SS" specifies a relative time `n" `
        "[-T {tcp[,port]|np|lpc|via}] = connects to sql server using the specified protocol `n" `
        "[-Debug] = print some verbose messages for debugging where appropriate `n" `
        "[START], [STOP], [STOP_ABORT] = service commands for a registered (-R) SQLDIAG service `n" `
        ""        -ForegroundColor Green

        exit
}

function main 
{

    [bool] $debug_on = $false

    if ($DebugOn -eq $true)
    {
        $debug_on = $true
    }
	
	if (Check-ElevatedAccess -eq $true)
	{
		exit
	}
	

    $validFileAttributes = Confirm-FileAttributes $debug_on
        if (-not($validFileAttributes)){
            Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") File attribute validation FAILED. Exiting..." -ForegroundColor Red
            return
        }
        
    
    [string[]] $argument_array = @()

    if ($ServiceState -iin "stop", "start", "stop_abort")
    {
        Write-Host "ServiceState = $ServiceState"
        $argument_array += $ServiceState   
    }
    elseif (($ServiceState -iin "--?", "/?", "?", "--help", "help") -or ($help -eq $true) )
    {
        PrintHelp
    }
    else
    {
        
        # [/I cfgfile] = sets the configuration file, typically either sqldiag.ini or sqldiag.xml.  Default is sqldiag.xml
        $lv_I = "/I" + $I

        # [/O outputpath] = sets the output folder.  Defaults to startupfolder\SQLDIAG (if the folder does not exist, the collector will attempt to create it)
        #if this is a full directory path make sure to trim a final backslash because SQLDiag would fail to start the service if that exists
        if ($O.Substring($O.Length -1) -eq "`\")
        {
          $O = $O.Substring(0,$O.Length -1)
        }

        $lv_O = "/O" + $O

        
        # [/P supportpath] = sets the support path folder.   By default, /P is set to the folder where the SQLdiag executable resides. 
		# The support folder contains SQLdiag support files, such as the XML configuration file, Transact-SQL scripts, and other files that the utility uses during diagnostics collection. 
		# If you use this option to specify an alternate support files path, SQLdiag will automatically copy the support files it requires to the specified folder if they do not already exist.
        $pwd = Get-Location
        
        if ([string]::IsNullOrWhiteSpace($P) -eq $false) 
        {
          #trim a final backslash because SQLDiag would fail to start the service if that exists
          if ($P.Substring($P.Length -1) -eq "`\")
          {
            $P = $P.Substring(0,$P.Length -1)
          }

          $lv_P = "/P" + $P 
        }

        else
        {
            $lv_P = "/P" + $pwd.Path
        }
        


        # [/N #] = output folder management at startup #: 1 = overwrite (default), 2 = rename (format is OUTPUT_00001,...00002, etc.)
        $lv_N = "/N" + $N

        # [/M machine1 [machine2 machineN]|@machinelistfile] = overrides the machines specified in the config file. When specifying more than one machine, separate each machine name with a space. "@" specifies a machine list file
        if ([string]::IsNullOrWhiteSpace($M))
        {
            $lv_M = ""
        }
        else 
        {
            $lv_M = "/M" + $M    
        }


        # [/Q]  = quiet mode -- supresses prompts (e.g., password prompts)

        if ($Q -eq $false)
        {
            $lv_Q = ""
        }
        else 
        {
            $lv_Q = "/Q"
        }
        
        # [/C #] = file compression type: 0 = none (default), 1 = NTFS, 2 = CAB

        $lv_C = "/C" + $C
        
        # [/G]  = generic mode -- SQL Server connectivity checks are not enforced; machine enumeration includes all servers, not just SQL Servers
        
        if ($G -eq $false)
        {
            $lv_G = ""
        }
        else 
        {
            $lv_G = "/G"
        }
        
        # [/R]  = registers the collector as a service

        if ($R -eq $false)
        {
            $lv_R = ""
        }
        else 
        {
            $lv_R = "/R"
        }
        
        # [/U]  = unregisters the collector as a service
        
        if ($U -eq $false)
        {
            $lv_U = ""
        }
        else 
        {
            $lv_U = "/U"
        }

        # [/A appname] = sets the application name to DIAG$appname.  If running as a service, this sets the service name to DIAG$appname

        if ([string]::IsNullOrWhiteSpace($A))
        {
            $lv_A = ""
        }
        else 
        {
            $lv_A = "/A" + $A
        }

        # [/L] = continuous mode -- automatically restarts when shutdown via /X or /E
        
        if ($L -eq $false)
        {
            $lv_L = ""
        }
        else 
        {
            $lv_L = "/L"
        }

        
        # [/X] = snapshot mode -- takes a snapshot of all configured diagnostics and shuts down immediately

        if ($X -eq $false)
        {
            $lv_X = ""
        }
        else 
        {
            $lv_X = "/X"
        }

        
        # [/B [+]YYYYMMDD_HH:MM:SS] = specifies the date/time to begin collecting data; "+" specifies a relative time

        if ([string]::IsNullOrWhiteSpace($B))
        {
            $lv_B = ""
        }
        else 
        {
            $lv_B = "/B" + $B
        }
        
        # [/E [+]YYYYMMDD_HH:MM:SS]  = specifies the date/time to end data collection; "+" specifies a relative time
        
        if ([string]::IsNullOrWhiteSpace($E))
        {
            $lv_E = ""
        }
        else 
        {
            $lv_E = "/E" + $E
        }

        # [/T {tcp[,port]|np|lpc|via}] = connects to sql server using the specified protocol

        if ([string]::IsNullOrWhiteSpace($T))
        {
            $lv_T = ""
        }
        else 
        {
            $lv_T = "/T" + $T
        }    
        
        [string[]] $argument_arrayTemp = @()  
		
        if ($lv_U -eq "/U")
        {
            $argument_arrayTemp = $lv_A, $lv_U
        }
        else 
        {
            # special case if user typed /r instead of -R
            if ($ServiceState -eq "/r")
            {
                $lv_R = "/R"
            }
            
            $argument_arrayTemp = $lv_I, $lv_O, $lv_P, $lv_N, $lv_M, $lv_Q, $lv_C, $lv_G, $lv_R, $lv_A, $lv_L, $lv_X, $lv_B, $lv_E, $lv_T
        }
        
        foreach ($item in $argument_arrayTemp)
        {
            if (($item.Trim()) -ne "")
            {
                $argument_array += $item.Trim()
            }		
        }
        
    }

	# locate the SQLDiag.exe path for this version of PSSDIAG
	[string]$sqldiag_path = FindSQLDiag
	
	if ("Path_Error_" -eq $sqldiag_path)
	{
		#no valid path found to run SQLDiag.exe, so exiting
		exit
	}

		

	#Translate Performance Counters if((Get-WinSystemLocale).name -notlike "en*")
    & .\perfmon_translate.ps1

    # launch the sqldiag.exe process and print the last 5 lines of the console file in case there were errors

    Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") Executing: $sqldiag_path $argument_array"
    Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") Number of parameters passed: $($argument_array.Length)"
    & $sqldiag_path $argument_array

    
    $console_log = ".\output\internal\##console.log"

    if (($R -eq $true) -or ($ServiceState -in "stop", "start", "stop_abort") -or ($U -eq $true))
    {
        if($R -eq $true)
        {
            Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") Registered SQLDiag as a service. Please make sure you run 'pssdiag.ps1 START' or 'SQLDIAG START' or 'net start SQLDIAG'" -ForegroundColor Green
        }

        if($U -eq $true)
        {
            Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") Un-registered SQLDiag as a service." -ForegroundColor Green
        }
        
    }
    elseif (Test-Path -Path $console_log )
    {
        Write-Warning "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") Displaying the last 5 lines from \output\internal\##console.log file. If SQLDiag did not run for some reason, you may be reading an old log."
	    Get-Content -Tail 5 $console_log 
        Write-Host "$(Get-Date -Format "MM/dd/yyyy HH:mm:ss.fff") SQLDiag has completed. You can close the window. If you got errors, please review \output\internal\##SQLDIAG.LOG file"
    }

	

}


main

# SIG # Begin signature block
# MIIoLwYJKoZIhvcNAQcCoIIoIDCCKBwCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDWH/uF3gAEOX7S
# O1LRSFoO3Lq4O30N+c1VC/Rhl/MUkaCCDXYwggX0MIID3KADAgECAhMzAAADTrU8
# esGEb+srAAAAAANOMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwMzE2MTg0MzI5WhcNMjQwMzE0MTg0MzI5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDdCKiNI6IBFWuvJUmf6WdOJqZmIwYs5G7AJD5UbcL6tsC+EBPDbr36pFGo1bsU
# p53nRyFYnncoMg8FK0d8jLlw0lgexDDr7gicf2zOBFWqfv/nSLwzJFNP5W03DF/1
# 1oZ12rSFqGlm+O46cRjTDFBpMRCZZGddZlRBjivby0eI1VgTD1TvAdfBYQe82fhm
# WQkYR/lWmAK+vW/1+bO7jHaxXTNCxLIBW07F8PBjUcwFxxyfbe2mHB4h1L4U0Ofa
# +HX/aREQ7SqYZz59sXM2ySOfvYyIjnqSO80NGBaz5DvzIG88J0+BNhOu2jl6Dfcq
# jYQs1H/PMSQIK6E7lXDXSpXzAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUnMc7Zn/ukKBsBiWkwdNfsN5pdwAw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMDUxNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAD21v9pHoLdBSNlFAjmk
# mx4XxOZAPsVxxXbDyQv1+kGDe9XpgBnT1lXnx7JDpFMKBwAyIwdInmvhK9pGBa31
# TyeL3p7R2s0L8SABPPRJHAEk4NHpBXxHjm4TKjezAbSqqbgsy10Y7KApy+9UrKa2
# kGmsuASsk95PVm5vem7OmTs42vm0BJUU+JPQLg8Y/sdj3TtSfLYYZAaJwTAIgi7d
# hzn5hatLo7Dhz+4T+MrFd+6LUa2U3zr97QwzDthx+RP9/RZnur4inzSQsG5DCVIM
# pA1l2NWEA3KAca0tI2l6hQNYsaKL1kefdfHCrPxEry8onJjyGGv9YKoLv6AOO7Oh
# JEmbQlz/xksYG2N/JSOJ+QqYpGTEuYFYVWain7He6jgb41JbpOGKDdE/b+V2q/gX
# UgFe2gdwTpCDsvh8SMRoq1/BNXcr7iTAU38Vgr83iVtPYmFhZOVM0ULp/kKTVoir
# IpP2KCxT4OekOctt8grYnhJ16QMjmMv5o53hjNFXOxigkQWYzUO+6w50g0FAeFa8
# 5ugCCB6lXEk21FFB1FdIHpjSQf+LP/W2OV/HfhC3uTPgKbRtXo83TZYEudooyZ/A
# Vu08sibZ3MkGOJORLERNwKm2G7oqdOv4Qj8Z0JrGgMzj46NFKAxkLSpE5oHQYP1H
# tPx1lPfD7iNSbJsP6LiUHXH1MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGg8wghoLAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAANOtTx6wYRv6ysAAAAAA04wDQYJYIZIAWUDBAIB
# BQCggbAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEILoQZ+n3W2rp1XpydbqkaYMq
# PPk0skweQFvofl16P8L5MEQGCisGAQQBgjcCAQwxNjA0oBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEcgBpodHRwczovL3d3d3cubWljcm9zb2Z0LmNvbTANBgkqhkiG9w0B
# AQEFAASCAQA2/QLIvhGV4toyTTTYUiXesQcO1fC/WwfRmCSNu1Bi97dsyTRFAElF
# JZOesy2uqFHQZWIDCVbVMsiGYav5ENkDnv2Q+MUqj5CdBSt7jnN5gKV8xr4vm2sN
# W7BlsLjM2D1wFMMSj0z0EDNgL2ixtsecu+HVeiQuGjHDrC+4MzcXCMLSoVmng95+
# 9GHRg26dczJ7u9hC9yD5xvxo5fSgHQrPcyORXKDAs1JQufpExkS6SMdh4138pJsc
# SiXbxBibcDitQw/sUHQXS5Lth+fAbokrUW/Y+S6y1/eNFk7Hj52Sj/JrNSZrGEEA
# U+uKAn8tyv89ZMop1WiJEty5x1a151QpoYIXlzCCF5MGCisGAQQBgjcDAwExgheD
# MIIXfwYJKoZIhvcNAQcCoIIXcDCCF2wCAQMxDzANBglghkgBZQMEAgEFADCCAVIG
# CyqGSIb3DQEJEAEEoIIBQQSCAT0wggE5AgEBBgorBgEEAYRZCgMBMDEwDQYJYIZI
# AWUDBAIBBQAEIMndclfdoAIzLJjJOQIjy9e5jMQOD9it+sIpf4w/R09xAgZky+Ut
# KNsYEzIwMjMwODA0MDgyMDI4LjcxM1owBIACAfSggdGkgc4wgcsxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBB
# bWVyaWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo3RjAw
# LTA1RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZaCCEe0wggcgMIIFCKADAgECAhMzAAAB1akCz8WnyelaAAEAAAHVMA0GCSqGSIb3
# DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIzMDUyNTE5
# MTIzMFoXDTI0MDIwMTE5MTIzMFowgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlv
# bnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjo3RjAwLTA1RTAtRDk0NzElMCMG
# A1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcN
# AQEBBQADggIPADCCAgoCggIBAMV9qTns6mH2+7G2WgAGItzp6dP7IofrX1v46EZ2
# TKGA3ORfzQpQYj+MSo5UxXhKq39Q8UWJ3Ha3u/ZIROPa0DO5Uq0N+rYcGm7zS9nS
# /JAPJ1W3gwMvi0lIqqBih8LEMgGtbMkmOAGiUp04nHW63ZPI5z5Q6bt73a1U8emN
# 2D46Z/fVMtR/+ii7IA4n8iefaKHcBI/RBib4AVCOFgM0O7y7Mx3AcXlB3Cyxw1r0
# 9VIZ50t0Muj2MvoOg8Xg1ijTqW+8RC5In0ibBl8EYvL/yGkTtEPh7C8kqYzX63p5
# C4SxNeOsYzZaORbXxKBRnyf5Wkva6ToCEOQJrfnkjnfWnQmSqmiift0e4tR1lJA7
# jSqZUhDqpAJqe8iZOqY2AT+s8nSuCvSEw8j+5HVP+JovSYSrhupqT7exrwj4UBg4
# j88LtX7MR6T6x3Ja1pf6d1saW/9ElvmZBoafw26duR+8cPVC3kPSua0w56RgyrtC
# NioTcUQ//ABjhMO4nGy2OxrYdeLbJQMSDgwkvr8m+xBdOg5n4jFHopPm3l8HkWll
# gGlUsyZrembnPpVe+Retizfc1cmpVYvCKzBrs1QVXzsSzayi70h3DfIBmYchhaA5
# D4MhjWdjdobkM4OLA3WsnIRv6ZtYNqCt1XFydyvpQoo7j16g1NcRb6xxR/obBcbQ
# oTKZAgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUr9Bco07flsEw7PdHmCJfsCVrY5ow
# HwYDVR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKg
# UIZOaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0
# JTIwVGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAw
# XjBcBggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9j
# ZXJ0cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQw
# DAYDVR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8E
# BAMCB4AwDQYJKoZIhvcNAQELBQADggIBAGZF12q9C7KNGnHQcbG86p98WtuAUCDS
# Pza/S/tH7/xrvRLZXi3vIpgpKxAYjqm+3UDwkaa5nKOYhebDbcCQjltmTG9KDCzy
# usG0nD29qQRyRxYVBvskbpvrXzHSz1DcMvR1GrjpBlGebtTrbfiV5y+Oy0CjDfR0
# /ROchpw9Yqk9zdCAH5YOeCU3Z91PWu5DpYhUF6eamOkb3KlEA0pTHk1Fyl0kBBbY
# WoQdNLc21v7S0KoiQ0cnloWwXp6FGi9ZmnQxgjP1ukkeLHRWuN0tUw6l7vC/ra33
# QTdSsTYqZXClDnCwwPphSxygKxJFBmsDkBvBM4Jkml4bbPe8Oj+G688rxN5MnYu2
# 78i1eDEiUg5Cn+1scCI3xem3D8mYhmD151D8WINogjAblgex+ba7tPA4XJ3o6ovD
# XxnmP8i8M/OWTBYnGTpEckXl1Lizd+fIvDcMcF7kNq/opgHifzH9wSYP9Hjj/yBL
# k9+4bWyuMt3LIa3KHQqJENKaPD59ruLVU+h6aJ0NY1nuSw1p0xp3hmgO+CSo5XgD
# pr43wchz8/qDSKut7MtZSBspdI3yIf1E/5YkXHl8EcTgAXGtsBRDZmfmMOYcAjfB
# hxAOecRg/nUDvlYXA+y8Gt+tvX7prV+5MQfUBh044zLx9fzEqjQTRiz7tvEi8U+x
# SlLN8WMGiWaHMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+
# F2Az/1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU
# 88V29YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqY
# O7oaezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzp
# cGkNyjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0Xn
# Rm7KMtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1
# zcRfNN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZN
# N3SUHDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLR
# vWoYWmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTY
# uVD5C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUX
# k8A8FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB
# 2TASBgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKR
# PEY1Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0g
# BFUwUzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5t
# aWNyb3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQM
# MAoGCCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQE
# AwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQ
# W9fOmhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNv
# bS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBa
# BggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqG
# SIb3DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOX
# PTEztTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6c
# qYJWAAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/z
# jj3G82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz
# /AyeixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyR
# gNI95ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdU
# bZ1jdEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo
# 3GcZKCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4K
# u+xBZj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10Cga
# iQuPNtq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9
# vMvpe784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGC
# A1AwggI4AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046N0YwMC0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMV
# AE4SL5L9lUV7rDUh3fWboqB7bqU0oIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzAR
# BgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1p
# Y3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3Rh
# bXAgUENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDodwxtMCIYDzIwMjMwODA0MDUz
# NDM3WhgPMjAyMzA4MDUwNTM0MzdaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOh3
# DG0CAQAwCgIBAAICXcUCAf8wBwIBAAICEwQwCgIFAOh4Xe0CAQAwNgYKKwYBBAGE
# WQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDAN
# BgkqhkiG9w0BAQsFAAOCAQEAqaPjxLsf0WFMyrcAiXfeLOZDHjgxdEuvQvFyBzXo
# MuEG9u/S58s/+b37LGFSbUhaHwR6pgRUDNeIcXz6+oExGkc6JiUySIMhSlLEx44Z
# hpiBnE7XTu0HOYp1fVjQKgp+Le7KBMauCTzWu9I0YQerzGib+eKAOKMfmo/UYYzW
# 40CZUR1DcrNmu+eImppj69NtR0pR8twyKdhB0vAgaS7zbb3Jrp35bpAlqpdPVlVI
# wOoFkh9ChbqdBWGiuL0lA2tvsrpsYErdbSLo+a80mGtX3ZTa3s3Ud7KQ3IlotNIY
# JgsnXrFgW7yYfEmPaymuSMfUhc/QWUNjRAJw5VqCQIKCKDGCBA0wggQJAgEBMIGT
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB1akCz8WnyelaAAEA
# AAHVMA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQ
# AQQwLwYJKoZIhvcNAQkEMSIEIKctcGcdeHWzhbTrPcRiQlXhszrKt56vhiA36mqY
# AErAMIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQg2b8jhgzXrokwzsQohxi+
# VxuvYIeMoLQtQ6alkhsGwf8wgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAdWpAs/Fp8npWgABAAAB1TAiBCAviHXre+l9pQXRtlvdptPt
# fFB1cHsEMeMPadevy3dZjTANBgkqhkiG9w0BAQsFAASCAgCpkQuWXbx43umvx5MP
# LbbohpIK+coC2nxlULpEa/EqQZWwhQ4O3bmZ9+ROkBeRwa9D7f33B6CvYNBPmIqw
# g6WrjEX9FyECs8u6yIQOYMf+l3cSQIe+TdGXui4dzh2K+NAcstuQQ0UWrrZpKiQQ
# zq6OsbzOSnjKAUPWWa6EkHYtYvyiN9MfIhdRroqgwA0BkZ1h90Ff3vvp3RuXciRE
# uhYStdj5NfZhvUyXFuVkKz2419kgKYitxK3Texo88exgs7AFzIMxxclwp3WuhthT
# I5bMwtqrT2CctJfJCZECtVBnaWWnmeYs+jkXo4Fow1TFoUHmix8miZeAYAaZHBEd
# RMY9w6OBNbMn/Y7TZgQQntolldTEFDYmACOrcgT6sikIxassVFoDsEMKizWQ0QOU
# zIYa/pvX9ywWWBgAdcpgR6PtufwQTqhG6PD3qRd5+xfugcp88oww9qksx0DNM8Zv
# KcraCwmULmSmsjou90ed00+InQakVQVfqfRI0YcaYD45PUj++6Eqv7o3YZB7DVMk
# 4A7OZ/Z5wLSw2b6o6CnoBoTXWSF/aPQSPr1JmPxCdE5HbRxp7c6oIm4f87eFkSwV
# x6c+dOnKn+ifs5clAbdjwFvDDKFthAcqwPBA8n5v3nKI1dnYtru8uor/3vvkJ3rl
# rlCQUynN6oBruOcWRnxImNhutQ==
# SIG # End signature block
